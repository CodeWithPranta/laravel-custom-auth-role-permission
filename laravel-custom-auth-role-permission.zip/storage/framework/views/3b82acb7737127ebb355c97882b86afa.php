<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <?php if(session('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('message')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <script>
        // Close alert after 5 seconds
        setTimeout(function() {
            document.querySelector('.alert').remove();
        }, 5000);
    </script>
    <?php endif; ?>
    <a href="<?php echo e(route('events.create')); ?>" class="btn btn-success mb-3">নতুন ইভেন্ট পোস্ট করুন</a>
    <div class="row">
        <div class="col">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>সিরিয়াল নং</th>
                            <th>ইভেন্ট টাইটেল</th>
                            <th>ডেসক্রিপশন</th>
                            <th>পোস্ট ডেট</th>
                            <th>অপারেশন</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $serial_no = 1; ?>
                       <?php if(!empty($postEvents)): ?>
                       <?php $__currentLoopData = $postEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <tr>
                           <td><?php echo e($serial_no++); ?></td>
                           <td><?php echo e($postEvent->title); ?></td>
                           <td><?php echo e(\Illuminate\Support\Str::limit($postEvent->description, 90)); ?></td>
                           <td><?php echo e(\Carbon\Carbon::parse($postEvent->created_at)->format('M j, Y')); ?></td>
                           <td class="d-flex justify-content-center">
                               <a href="<?php echo e(route('events.edit', $postEvent)); ?>" class="link btn text-success"><i class="bi bi-pencil"></i> আপডেট</a>
                               <form action="<?php echo e(route('events.destroy', $postEvent->id)); ?>" method="post">
                                   <?php echo csrf_field(); ?>
                                   <?php echo method_field('delete'); ?>
                                   <button type="submit" class="link btn text-danger"><i class="bi bi-trash"></i> ডিলিট</button>
                               </form>
                           </td>
                       </tr>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       <?php endif; ?>
                    </tbody>
                </table>

                <?php echo e($postEvents->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/events/index.blade.php ENDPATH**/ ?>