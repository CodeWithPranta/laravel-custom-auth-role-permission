<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2>Users List</h2>
    <div class="row">
        <div class="mt-3 col-md-6">
            <form action="<?php echo e(route('adminusers.index')); ?>" method="GET" class="d-flex mx-auto my-3 my-lg-0">
                <input class="form-control me-2" type="text" name="search" placeholder="Type user phone or name or address">
                <button class="btn btn-outline-success" type="submit">Search</button>
            </form>
        </div>
    </div>
    <div class="row">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Serial No.</th>
                        <th>Name</th>
                        <th>Phone</th>
                        <th>Father's</th>
                        <th>Mother's</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $serial_no = 1; ?>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($serial_no++); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->father_name); ?></td>
                        <td><?php echo e($user->mother_name); ?></td>
                        <td>
                            <?php if($user->is_baruikati == 'বারুইকাটি'): ?>
                            <?php echo e(__('বারুইকাটি')); ?>

                            <?php else: ?>
                            <?php echo e($user->address); ?>

                            <?php endif; ?>
                        </td>
                        <td>Edit Delete Assign Role and Permissions</td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8">
            <?php echo $users->links(); ?>  
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.root', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users.blade.php ENDPATH**/ ?>