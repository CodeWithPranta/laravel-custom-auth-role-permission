<?php if(!empty($postEvents)): ?>
<?php $__currentLoopData = $postEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <h4 class="card-title"><?php echo e($postEvent->title); ?></h4>
                <p class="card-text"><?php echo e($postEvent->description); ?></p>
                <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
                        <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                    </div>
                    <small class="text-muted">Posted on: <?php echo e(\Carbon\Carbon::parse($postEvent->created_at)->format('M j, Y')); ?></small>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /var/www/html/resources/views/includes/post_events.blade.php ENDPATH**/ ?>