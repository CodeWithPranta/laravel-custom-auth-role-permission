<div class="container-fluid mb-5">
    <div class="row">
        <div class="col-md-12">
            <div class="footer-wrapper">
                <div class="container">
                  <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-5 border-top">
                    <div class="col-md-4 d-flex align-items-center">
                      <span class="text-muted">&copy; 2023, প্রান্ত মজুমদার</span>
                    </div>

                    <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
                      <li class="ms-3"><a class="text-muted" href="https://facebook.com/webmastermazumder"><svg class="bi" width="24" height="24"><use xlink:href="#facebook"/></svg></a></li>
                    </ul>
                  </footer>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/footer-component.blade.php ENDPATH**/ ?>