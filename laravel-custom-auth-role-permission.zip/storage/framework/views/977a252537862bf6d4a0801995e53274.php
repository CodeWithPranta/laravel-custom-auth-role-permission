<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">Chat</div>
            <div class="card-body" id="chat-messages">
                
            </div>
            <form id="chat-form">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <input type="text" name="message" class="form-control" placeholder="Type a message...">
                    <button type="submit" class="btn btn-primary">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH /var/www/html/resources/views/chat.blade.php ENDPATH**/ ?>