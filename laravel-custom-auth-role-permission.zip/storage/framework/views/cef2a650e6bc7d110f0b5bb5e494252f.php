<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row row-cols-1 row-cols-md-4 g-4">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card">
                        <?php if(!empty($user->profile->avatar)): ?>
                        <img src="<?php echo e(asset('storage/files/avatars/' . $user->profile->avatar)); ?>" class="card-img-top rounded-circle" alt="<?php echo e($user->name); ?> Avatar" width="50%">
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title">নাম: <?php echo e($user->name); ?></h5>
                            <h5 class="card-title">পিতা: <?php echo e($user->father_name); ?></h5>
                            <?php if($user->is_baruikati == 'বারুইকাটি'): ?>
                                <?php echo e(__('ঠিকানা: বারুইকাটি')); ?>

                            <?php else: ?>
                            <p>ঠিকানা: <?php echo e($user->address); ?></p>
                            <?php endif; ?>
                            <?php if(!empty($user->profile->profession)): ?>
                            <p>পেশা: <?php echo e($user->profile->profession); ?></p>
                            <?php endif; ?>
                            <?php if(!empty($user->profile->blood_group)): ?>
                            <p>রক্তের গ্রুপ: <?php echo e($user->profile->blood_group); ?></p>
                            <?php endif; ?>
                        </div>
                        <a href="<?php echo e(url('chatify/' . $user->id)); ?>" class="btn btn-success">Live Chat</a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users.blade.php ENDPATH**/ ?>