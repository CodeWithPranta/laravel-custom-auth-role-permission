<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <?php if(session('message')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('message')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <script>
            // Close alert after 5 seconds
            setTimeout(function() {
                document.querySelector('.alert').remove();
            }, 5000);
        </script>
        <?php endif; ?>
      <div class="col-md-4">
        <div class="card shadow-sm">
            <?php if($profile): ?>
            <img src="<?php echo e(asset('storage/files/avatars/' . $profile->avatar)); ?>" alt="Avatar" class="card-img-top img-fluid">
            <?php endif; ?>
          <div class="card-body">
            <h5 class="card-title"><?php echo e($user->name); ?></h5>
            <p class="card-text"><?php echo e($user->phone); ?></p>
            <a href="<?php echo e(route('user.edit_profile')); ?>">প্রোফাইল এডিট করুন</a>
          </div>
        </div>
      </div>
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">
            প্রোফাইল ইনফরমেশন
          </div>
          <div class="card-body">
            <div class="row">
              <div class="col-md-6">
                <p><strong>পিতার নাম:</strong> <?php echo e($user->father_name); ?></p>
                <p><strong>মাতার নাম:</strong> <?php echo e($user->mother_name); ?></p>
                <?php if($profile): ?>
                <p><strong>জন্মতারিখ:</strong> <?php echo e($profile->birth_date); ?></p>
                <p><strong>জেন্ডার:</strong> <?php echo e($profile->gender); ?></p>
                <p><strong>রক্তের গ্রুপ:</strong> <?php echo e($profile->blood_group); ?></p>
                <p><strong>পেশা:</strong> <?php echo e($profile->profession); ?></p>
                <?php endif; ?>
                <p><strong>ঠিকানা:</strong> <?php if($user->is_baruikati == 'বারুইকাটি'): ?>
                    <?php echo e(__('বারুইকাটি')); ?>

                    <?php else: ?>
                    <?php echo e($user->address); ?>

                <?php endif; ?></p>
              </div>
              <div class="col-md-6">
                <?php if($profile): ?>
                <p><strong>বায়োগ্রাফি:</strong> <?php echo e($profile->bio); ?></p>
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/user_profile.blade.php ENDPATH**/ ?>